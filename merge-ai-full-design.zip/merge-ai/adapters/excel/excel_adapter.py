"""
Excel adapter: full CRUD on a single .xlsx workbook, on top of BaseAdapter.
"""

from __future__ import annotations

import os
from typing import Any, Optional

import openpyxl
from openpyxl.worksheet.worksheet import Worksheet

from adapters.base_adapter import BaseAdapter
from adapters.common.change_preview import ChangePreview


class ExcelAdapter(BaseAdapter):
    kind = "excel"
    can_write = True

    def __init__(self, file_path: str):
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"Excel file not found: {file_path}")
        super().__init__(os.path.abspath(file_path))
        self.file_path = self.source
        self._wb = openpyxl.load_workbook(self.file_path, data_only=False)

    # ---------- introspection ----------

    def list_sheets(self) -> list[str]:
        return self._wb.sheetnames

    def _sheet(self, sheet_name: Optional[str] = None) -> Worksheet:
        if sheet_name is None:
            return self._wb.active
        if sheet_name not in self._wb.sheetnames:
            raise KeyError(f"Sheet '{sheet_name}' not found in {self.file_path}")
        return self._wb[sheet_name]

    # ---------- BaseAdapter contract ----------

    def read_all(self, max_rows_per_sheet: int = 200) -> str:
        chunks = []
        for name in self.list_sheets():
            ws = self._sheet(name)
            chunks.append(f"--- Sheet: {name} ---")
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i >= max_rows_per_sheet:
                    chunks.append(f"... ({ws.max_row - max_rows_per_sheet} more rows truncated)")
                    break
                chunks.append(", ".join("" if v is None else str(v) for v in row))
        return "\n".join(chunks)

    def search(self, value: Any) -> list[tuple[str, str]]:
        hits: list[tuple[str, str]] = []
        for name in self.list_sheets():
            ws = self._sheet(name)
            for row in ws.iter_rows():
                for cell in row:
                    if cell.value == value:
                        hits.append((name, cell.coordinate))
        return hits

    def close(self) -> None:
        self._wb.close()

    # ---------- READ ----------

    def read_cell(self, cell: str, sheet_name: Optional[str] = None) -> Any:
        return self._sheet(sheet_name)[cell].value

    def read_range(self, cell_range: str, sheet_name: Optional[str] = None) -> list[list[Any]]:
        ws = self._sheet(sheet_name)
        return [[c.value for c in row] for row in ws[cell_range]]

    # ---------- WRITE (confirm-first) ----------

    def write_cell(self, cell: str, new_value: Any, sheet_name: Optional[str] = None) -> ChangePreview:
        ws = self._sheet(sheet_name)
        old_value = ws[cell].value

        def _apply():
            ws[cell] = new_value
            self._wb.save(self.file_path)

        return ChangePreview(
            description="write_cell", source=self.file_path,
            location=f"{ws.title}!{cell}", old_value=old_value, new_value=new_value,
            _apply_fn=_apply,
        )

    def append_row(self, values: list[Any], sheet_name: Optional[str] = None) -> ChangePreview:
        ws = self._sheet(sheet_name)
        target_row = ws.max_row + 1

        def _apply():
            ws.append(values)
            self._wb.save(self.file_path)

        return ChangePreview(
            description="append_row", source=self.file_path,
            location=f"{ws.title}!row {target_row}", old_value=None, new_value=values,
            _apply_fn=_apply,
        )

    def delete_row(self, row_index: int, sheet_name: Optional[str] = None) -> ChangePreview:
        ws = self._sheet(sheet_name)
        old_values = [c.value for c in ws[row_index]]

        def _apply():
            ws.delete_rows(row_index)
            self._wb.save(self.file_path)

        return ChangePreview(
            description="delete_row", source=self.file_path,
            location=f"{ws.title}!row {row_index}", old_value=old_values, new_value=None,
            _apply_fn=_apply,
        )
