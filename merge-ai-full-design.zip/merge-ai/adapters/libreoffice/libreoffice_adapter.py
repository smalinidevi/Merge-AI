"""
LibreOffice live-document adapter, via PyUNO — the "edit the document
that's actually open in front of the user right now" adapter, distinct
from ExcelAdapter/WordAdapter which operate on files on disk (possibly
closed). This is what makes "merge with whatever's open" feel instant
instead of "save first, then let the AI open a copy."

Stubbed in this sandbox because it requires:
  - A running `soffice --accept="socket,host=localhost,port=2002;..."` process
  - The `uno` / `unohelper` Python modules that ship with LibreOffice itself
    (not installable via pip in a normal venv — they come from the LO install)

Real setup instructions (Phase 4):
    soffice --headless --accept="socket,host=localhost,port=2002;urp;" &
    # then this adapter connects via the UNO socket bridge

The method shapes below are the real contract; fill in `_connect()` and the
UNO calls in Phase 4 on a machine with LibreOffice installed.
"""

from __future__ import annotations

from typing import Any

from adapters.base_adapter import BaseAdapter
from adapters.common.change_preview import ChangePreview


class LibreOfficeAdapter(BaseAdapter):
    kind = "libreoffice_live"
    can_write = True

    def __init__(self, source: str = "localhost:2002"):
        super().__init__(source)
        self._connected = False
        self._document = None  # would hold the UNO document object

    def _connect(self) -> None:
        """
        TODO (Phase 4, requires LibreOffice installed + running):
            import uno
            from com.sun.star.beans import PropertyValue
            localContext = uno.getComponentContext()
            resolver = localContext.ServiceManager.createInstanceWithContext(
                "com.sun.star.bridge.UnoUrlResolver", localContext)
            context = resolver.resolve(
                "uno:socket,host=localhost,port=2002;urp;StarOffice.ComponentContext")
            ...
        """
        raise NotImplementedError(
            "PyUNO bridge requires a LibreOffice install + running soffice "
            "process. Not available in this sandbox."
        )

    # ---------- BaseAdapter contract ----------

    def read_all(self) -> str:
        raise NotImplementedError("Connect to a live LibreOffice doc first (Phase 4).")

    def search(self, value: Any) -> list:
        raise NotImplementedError("Connect to a live LibreOffice doc first (Phase 4).")

    # ---------- WRITE (confirm-first, same pattern as ExcelAdapter) ----------

    def write_cell(self, cell: str, new_value: Any, sheet_name: str | None = None) -> ChangePreview:
        """Same shape as ExcelAdapter.write_cell, but against the live open
        document instead of a file on disk — no save/reload round-trip."""
        raise NotImplementedError("Connect to a live LibreOffice doc first (Phase 4).")
