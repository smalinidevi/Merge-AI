"""
Browser adapter. This side (Python) can't reach into a browser tab
directly — it needs a companion Chrome extension that talks to this
process over a local bridge (native messaging host, or a plain local
WebSocket/HTTP server this adapter runs and the extension connects to).

Not implemented in this sandbox (no browser, no extension to pair with).
This file defines the contract main.py/session_manager will call once the
extension exists — build order per ROADMAP.md: extension + local bridge
server first, then wire this adapter's methods to real messages.
"""

from __future__ import annotations

from typing import Any

from adapters.base_adapter import BaseAdapter
from adapters.common.change_preview import ChangePreview


class BrowserAdapter(BaseAdapter):
    kind = "browser"
    can_write = True  # can fill forms / click, once the bridge exists

    def __init__(self, source: str = "active-tab"):
        super().__init__(source)
        self._bridge_connected = False

    def _ensure_bridge(self) -> None:
        """
        TODO (Phase 4):
          - Run a local server (e.g. websockets on 127.0.0.1:8765)
          - Chrome extension connects to it on load
          - Extension relays: active tab URL/title/DOM text on request;
            executes fill/click actions on request, and reports back result
        """
        raise NotImplementedError(
            "Browser bridge (extension + local server) not set up in this "
            "sandbox — Phase 4 work."
        )

    # ---------- BaseAdapter contract ----------

    def read_all(self) -> str:
        raise NotImplementedError("Browser bridge not connected (Phase 4).")

    def search(self, value: Any) -> list:
        raise NotImplementedError("Browser bridge not connected (Phase 4).")

    # ---------- WRITE (confirm-first, same pattern as other adapters) ----------

    def fill_form_field(self, selector: str, new_value: str) -> ChangePreview:
        """`selector` is a CSS selector the extension resolves in the page."""
        raise NotImplementedError("Browser bridge not connected (Phase 4).")

    def click(self, selector: str) -> ChangePreview:
        raise NotImplementedError("Browser bridge not connected (Phase 4).")
