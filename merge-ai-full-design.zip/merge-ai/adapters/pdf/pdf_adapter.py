"""
PDF adapter: read + structured extraction only. PDFs are not edited in
place in this design — there's no reliable "write back" for PDF text the
way there is for Excel/Word, so can_write stays False by design, not as a
missing feature.
"""

from __future__ import annotations

import os
from typing import Any

from pypdf import PdfReader

from adapters.base_adapter import BaseAdapter


class PdfAdapter(BaseAdapter):
    kind = "pdf"
    can_write = False

    def __init__(self, file_path: str):
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"PDF file not found: {file_path}")
        super().__init__(os.path.abspath(file_path))
        self.file_path = self.source
        self._reader = PdfReader(self.file_path)
        self._page_text_cache: list[str] | None = None

    def _page_texts(self) -> list[str]:
        if self._page_text_cache is None:
            self._page_text_cache = [page.extract_text() or "" for page in self._reader.pages]
        return self._page_text_cache

    # ---------- BaseAdapter contract ----------

    def read_all(self, max_chars: int = 20000) -> str:
        full = "\n\n".join(
            f"--- Page {i + 1} ---\n{text}" for i, text in enumerate(self._page_texts())
        )
        if len(full) > max_chars:
            return full[:max_chars] + f"\n... (truncated, {len(full) - max_chars} more chars)"
        return full

    def search(self, value: Any) -> list[int]:
        """Return 1-indexed page numbers containing the given substring
        (case-insensitive)."""
        needle = str(value).lower()
        return [
            i + 1 for i, text in enumerate(self._page_texts())
            if needle in text.lower()
        ]

    # ---------- extras ----------

    def read_page(self, page_number: int) -> str:
        """1-indexed page number."""
        texts = self._page_texts()
        if not (1 <= page_number <= len(texts)):
            raise IndexError(f"Page {page_number} out of range (1-{len(texts)})")
        return texts[page_number - 1]

    @property
    def page_count(self) -> int:
        return len(self._reader.pages)
