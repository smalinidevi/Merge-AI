"""
Vision adapter: the universal fallback that works on anything with no
native adapter — games, images, non-native/scanned PDFs, arbitrary apps.
Read-only by construction: there is no "write back into a screenshot."

Two responsibilities, kept separate on purpose:
  1. capture() — grab a screenshot of the active window (Phase 2 concern:
     needs a live X11 session + xdotool/wmctrl to find the active window,
     and mss/Pillow to grab pixels). Stubbed here because this sandbox has
     no display server; the method signature and TODOs are the real
     contract the overlay shell will call into.
  2. describe() — send the captured image + a question to a vision-capable
     model. This part has no OS dependency and is a plain HTTP call, so
     it's implemented for real (wire in your Anthropic API key via env var
     when running outside this sandbox).
"""

from __future__ import annotations

import base64
import os
from typing import Any, Optional

from adapters.base_adapter import BaseAdapter


class VisionAdapter(BaseAdapter):
    kind = "vision"
    can_write = False

    def __init__(self, source: str = "active-window"):
        super().__init__(source)
        self._last_image_path: Optional[str] = None
        self._last_description: Optional[str] = None

    # ---------- capture (Phase 2 — needs a real X11 display) ----------

    def capture(self, output_path: str = "/tmp/merge_ai_capture.png") -> str:
        """
        TODO (Phase 2, requires X11 session):
          1. Find active window: `xdotool getactivewindow`
          2. Get its geometry: `xdotool getwindowgeometry <id>`
          3. Screenshot just that region (e.g. via `mss`, cropped to geometry)
          4. Save PNG to output_path

        Raises NotImplementedError in this sandbox (no display server / no
        xdotool). This is the ONLY method in this file that needs a real
        desktop to run — describe() below works anywhere.
        """
        raise NotImplementedError(
            "Screenshot capture requires a live X11 session (xdotool + mss). "
            "Not available in this sandbox — implement in Phase 2 overlay build."
        )

    # ---------- describe (real, no OS dependency) ----------

    def describe(self, image_path: str, question: str) -> str:
        """
        Send an already-captured image + a question to a vision-capable
        model. Implemented as a real HTTP call — set ANTHROPIC_API_KEY in
        your environment to use it outside this sandbox.
        """
        import requests  # local import: keep this adapter's only extra dep scoped here

        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise RuntimeError("Set ANTHROPIC_API_KEY to use VisionAdapter.describe().")

        with open(image_path, "rb") as f:
            image_b64 = base64.b64encode(f.read()).decode("utf-8")

        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-sonnet-4-6",
                "max_tokens": 1000,
                "messages": [{
                    "role": "user",
                    "content": [
                        {"type": "image", "source": {
                            "type": "base64", "media_type": "image/png", "data": image_b64,
                        }},
                        {"type": "text", "text": question},
                    ],
                }],
            },
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()
        text_blocks = [b["text"] for b in data.get("content", []) if b.get("type") == "text"]
        description = "\n".join(text_blocks)

        self._last_image_path = image_path
        self._last_description = description
        return description

    # ---------- BaseAdapter contract ----------

    def read_all(self) -> str:
        return self._last_description or "(no capture described yet)"

    def search(self, value: Any) -> list:
        """Vision has no structured locations to search — best effort
        substring check against the last description."""
        if self._last_description and str(value).lower() in self._last_description.lower():
            return ["last_description"]
        return []
