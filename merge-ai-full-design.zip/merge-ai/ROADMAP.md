# Roadmap

## Phase 1 — Core adapters + session model (this repo, mostly done)
- [x] Shared `BaseAdapter` contract + `ChangePreview` confirm-first mechanism
- [x] Adapter registry (extension/kind -> adapter class)
- [x] Excel adapter — full CRUD
- [x] PDF adapter — read + search
- [x] Word adapter — read/write paragraphs
- [x] Terminal adapter — confirm-first execution
- [x] Session manager — multi-source, mixed adapter types, banner, staleness
- [x] CLI harness exercising all of the above
- [ ] Natural-language query layer (route "what's the total in..." to the right adapter calls)

## Phase 2 — Overlay shell (needs a real X11 desktop to build/test)
- [ ] `overlay/window_utils.py`: implement `get_active_window()` /
      `get_window_geometry()` for real via xdotool/wmctrl
- [ ] `overlay/overlay_app.py`: real GTK widget tree (PyGObject), always-on-top
      pinning, drag/resize
- [ ] Wire "Merge" button -> `guess_file_path_for_window()` (or manual file
      picker fallback) -> existing `Session.merge_file()` (no changes needed there)
- [ ] Render `Session.banner_text()` in a GTK label above the chat input
- [ ] Confirm dialog for `ChangePreview.apply()` (GTK modal, replacing the
      CLI's `input()` prompt)

## Phase 3 — Vision fallback (partially done)
- [x] `VisionAdapter.describe()` — real HTTP call to a vision model
- [ ] `VisionAdapter.capture()` — screenshot of active window (needs X11 +
      xdotool + mss, see docstring for exact steps)
- Universal fallback for anything without a native adapter (games, images,
  scanned/non-native PDFs)

## Phase 4 — Remaining adapters (each needs an external runtime this repo doesn't have)
- [ ] LibreOffice live-doc adapter (PyUNO) — needs `soffice` running with a
      UNO socket bridge; edits the document that's actually open, not a
      file-on-disk copy
- [ ] Browser adapter — needs a companion Chrome extension + local bridge
      server (native messaging host or local WebSocket)
- [ ] VS Code adapter — via VS Code's own extension API

## Cross-cutting, always
- Auto-execute only for read-only/advisory actions
- Confirm-first for anything that writes/deletes/sends/submits/executes —
  no per-adapter exceptions, including terminal
- Only explicitly merged sources are ever read — no silent system-wide capture
- X11 first; Wayland is a later, best-effort addition
