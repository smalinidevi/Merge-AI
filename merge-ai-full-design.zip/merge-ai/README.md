# Merge AI

A personal, general-purpose AI overlay assistant. It "merges" with whatever
you're working on — a spreadsheet, a PDF, a Word doc, a terminal, a browser
tab, or literally anything on screen via vision fallback — and lets you ask
an AI questions or make changes, across multiple merged sources at once.

## Architecture

Every adapter implements one contract (`adapters/base_adapter.py`):
`read_all()`, `search(value)`, `close()`, plus write/execute methods that
never apply directly — they return a `ChangePreview`
(`adapters/common/change_preview.py`) that must be explicitly `.apply()`'d.
This is the confirm-first rule, enforced structurally rather than by
convention: read-only actions execute immediately, anything that writes,
deletes, sends, or executes requires an explicit confirm, no exceptions
(terminal included).

`adapters/registry.py` maps file extensions and adapter "kinds" to the
right class, so `session/session_manager.py` and `main.py` never need to
know which adapter handles what — add a new adapter once, and it's usable
everywhere.

## Adapters

| Adapter | Status | Notes |
|---|---|---|
| Excel (`.xlsx`) | **Working** | Full CRUD via openpyxl, confirm-first writes |
| PDF (`.pdf`) | **Working** | Read + search only (PDFs aren't edited in place, by design) |
| Word (`.docx`) | **Working** | Read/write paragraphs via python-docx, confirm-first |
| Terminal | **Working** | Run shell commands, always confirm-first, no exceptions |
| Vision | **Partial** | `describe()` (send image + question to a vision model) is real; `capture()` is a structured stub — needs a live X11 display this sandbox doesn't have |
| LibreOffice (live doc, PyUNO) | **Stub** | Needs a running `soffice` + PyUNO bridge; method shapes are real, Phase 4 |
| Browser | **Stub** | Needs a companion Chrome extension + local bridge server; Phase 4 |
| Overlay shell (GTK) | **Stub** | Needs a live X11 desktop to render/test; class structure + session wiring is real, Phase 2 |

"Working" adapters are fully functional today, with passing tests. "Stub"
adapters have the real method signatures, docstrings explaining exactly
what to fill in, and raise `NotImplementedError` — they exist so the
registry/session/CLI layers already treat all seven adapter types
uniformly, and so Phase 2–4 work is "fill in this method" rather than
"redesign the architecture."

## Install

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt          # runtime deps
pip install -r requirements-dev.txt      # + test fixtures (reportlab, pytest)
```

## Quick start (CLI — stands in for the future overlay)

```bash
python main.py merge report.pdf ledger.xlsx notes.docx    # mixed adapter types, one session
python main.py read ledger.xlsx --sheet Sheet1 --cell A1
python main.py write ledger.xlsx --sheet Sheet1 --cell A1 --value "New Value"   # asks to confirm
python main.py search report.pdf ledger.xlsx --value "Revenue"
python main.py run "ls -la"                                # terminal adapter, confirm-first
```

## Tests

```bash
python tests/test_excel_adapter.py
python tests/test_all_adapters.py
```

## Project layout

```
merge-ai/
  main.py                        # CLI entry point / demo harness
  adapters/
    base_adapter.py               # shared contract every adapter implements
    registry.py                   # file-extension / kind -> adapter class
    common/change_preview.py      # confirm-first write mechanism
    excel/excel_adapter.py        # working
    pdf/pdf_adapter.py            # working
    word/word_adapter.py          # working
    terminal/terminal_adapter.py  # working
    vision/vision_adapter.py      # partial (describe() real, capture() stub)
    libreoffice/libreoffice_adapter.py   # stub, Phase 4
    browser/browser_adapter.py           # stub, Phase 4
  session/
    session_manager.py            # multi-source session, banner, staleness — adapter-agnostic
  overlay/
    overlay_app.py                # GTK app skeleton, stub pending X11 desktop
    window_utils.py                # xdotool/wmctrl wrappers, stub pending X11 desktop
  tests/
  ROADMAP.md
```

## Design rules (apply to every adapter, current and future)

1. **Auto vs confirm**: reads execute immediately; every write/execute
   returns a `ChangePreview` the caller must explicitly `.apply()`.
2. **Explicit scope**: only sources explicitly merged are touched — no
   silent directory scans or system-wide screen capture.
3. **No hidden persistence**: session metadata (titles, timestamps, which
   sources) is kept separate from source content; content isn't cached
   beyond the current operation.
4. **X11 first**: the overlay shell targets X11 (`echo $XDG_SESSION_TYPE`);
   Wayland support is an explicit later add-on, not a blocker.
