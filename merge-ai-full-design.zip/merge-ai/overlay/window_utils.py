"""
Thin wrappers around xdotool/wmctrl for X11 active-window detection.
Requires: a running X11 session (echo $XDG_SESSION_TYPE == "x11"),
and the `xdotool` and `wmctrl` binaries installed.

Stubbed (raises NotImplementedError) in this sandbox — there's no X server
here. On a real X11 desktop, swap `raise NotImplementedError` for the
subprocess calls sketched in each docstring.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ActiveWindowInfo:
    window_id: str
    title: str
    window_class: str


def get_active_window() -> ActiveWindowInfo:
    """
    Real implementation (Phase 2, on X11):
        import subprocess
        window_id = subprocess.check_output(["xdotool", "getactivewindow"]).decode().strip()
        title = subprocess.check_output(["xdotool", "getwindowname", window_id]).decode().strip()
        window_class = subprocess.check_output(
            ["xdotool", "getwindowclassname", window_id]
        ).decode().strip()
        return ActiveWindowInfo(window_id, title, window_class)
    """
    raise NotImplementedError(
        "Requires a live X11 session with xdotool installed. "
        "Not available in this sandbox."
    )


def get_window_geometry(window_id: str) -> dict:
    """
    Real implementation:
        subprocess.check_output(["xdotool", "getwindowgeometry", window_id])
        # parse "Position: x,y" and "Geometry: WxH" out of the output
    """
    raise NotImplementedError(
        "Requires a live X11 session with xdotool installed."
    )


def guess_file_path_for_window(info: ActiveWindowInfo) -> str | None:
    """
    Best-effort: many apps put the open file's name in the window title
    (LibreOffice, most PDF viewers do this — e.g. "report.pdf - Document Viewer").
    This is a heuristic, not a guarantee; return None if no plausible path
    can be extracted, and let the user pick the file manually instead.
    """
    raise NotImplementedError("Depends on get_active_window(); see above.")
