"""
GTK overlay shell — Phase 2. Structured skeleton: the class shape, session
wiring, and confirm-dialog pattern are real; the actual GTK widget tree is
left minimal/TODO since this sandbox has no display server to render or
test against.

Two states, per the design:
  - Normal window: a regular chat window (full-size, not pinned).
  - Overlay mode: small, always-on-top, draggable, stays pinned after
    "Merge" so you can keep asking about the same source while you work.

Run requirements (Phase 2, not met in this sandbox):
    - X11 session (see overlay/window_utils.py)
    - PyGObject / GTK3 or GTK4 installed (`import gi; gi.require_version(...)`)
"""

from __future__ import annotations

from typing import Optional

from session.session_manager import Session, SessionManager
from overlay.window_utils import get_active_window


class MergeOverlayApp:
    """
    Intended real structure (fill in with GTK once running on a real X11
    desktop):

        import gi
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk

        class MergeOverlayApp(Gtk.Window):
            def __init__(self):
                super().__init__(title="Merge AI")
                self.set_keep_above(True)   # always-on-top, once pinned
                ...

    Kept as a plain Python class here so the session-wiring logic (which
    is the actual interesting part for a skeleton) can be read, and later
    unit-tested, without a GTK runtime available.
    """

    def __init__(self):
        self.session_manager = SessionManager()
        self.pinned = False

    # ---------- the "Merge" button's handler ----------

    def on_merge_clicked(self) -> Session:
        """
        Real flow (Phase 2):
          1. get_active_window() -> ActiveWindowInfo
          2. guess_file_path_for_window(info) -> file path, or prompt user
          3. session.merge_file(path)  [existing session logic, unchanged]
          4. pin the window (self.set_keep_above(True)) if not already pinned
          5. render banner_text() above the chat input

        Everything from step 3 onward already works today via
        session_manager.Session — this method's job is purely to bridge
        "user clicked a button while looking at window X" into that
        existing, already-tested logic.
        """
        session = self.session_manager.get_active() or self.session_manager.new_session()
        try:
            active_window = get_active_window()  # raises NotImplementedError here
        except NotImplementedError:
            raise

        # Would continue: file_path = guess_file_path_for_window(active_window) ...
        self.pinned = True
        return session

    # ---------- rendering the status banner (Phase 2: bind to a GTK Label) ----------

    def render_banner(self) -> str:
        session = self.session_manager.get_active()
        if session is None:
            return "No sources merged yet."
        return session.banner_text()

    # ---------- confirm dialog for writes (Phase 2: bind to a GTK Dialog) ----------

    def confirm_change(self, preview_description: str) -> bool:
        """
        Real flow: show a GTK modal dialog with preview_description and
        Yes/No buttons, return the user's choice. Kept as a function
        signature here so the CLI's `input("Apply? [y/N]")` pattern and
        this future dialog are interchangeable call sites for the same
        ChangePreview.apply() logic in the adapters.
        """
        raise NotImplementedError("GTK dialog requires a running desktop session.")
